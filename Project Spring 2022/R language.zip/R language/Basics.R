# language of data science
# This is R. There is no if. Only how
# ~Simon Blomberg

# used for loading data
library(datasets)
#-------> show the first size lines of dataset
head(iris) 
#-------> summary statistics for iris data
summary(iris)
#-------> scatterplot matrix
plot(iris)
#------> boxplot
boxplot(iris)
#-------> clear packages
detach("package:datasets",unload = TRUE)
#-------> clear plot
dev.off()
#-------> clear console
cat("\014")
# packages are bundles of codes
# Base packages already installed  not loaded by default
# contributed need to be downloaded and used separatly

#Resources
# CRAN
# Crantastic
# Github






