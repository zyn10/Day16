#CRAN 
# Comprehensive R Archive Network

# cran.r-project.org

# dplyr = for manipulating data frames
# tidyr = for cleaning purposes
# stringr = for working with string data or text info
# lubridate = for date information
# httr = for dealing with website data
# ggvis = grammer of graphics
# ggplot2 = common for data visualization
# shiny = interactive applicatioins install on websites
# rio = for r importing and exporting data

# pacman can load all in one
 